# Ritim — Android

Bu proje Ritim Milkdrop Çalar'ın Android WebView paketidir.

## Derleme

Android Studio ile bu klasörü açın ve **Build > Build APK(s)** seçin.

APK çıktısı genellikle:
`app/build/outputs/apk/debug/app-debug.apk`

## Özellikler
- Ritim HTML/WebGL görselleştiricisi asset olarak paketlenir.
- Android sistem dosya seçicisi ile birden fazla ses dosyası seçilebilir.
- MP3/WAV/OGG/M4A/FLAC/AAC/OPUS gibi tarayıcının desteklediği formatlar kullanılabilir.
- Donanım hızlandırma açıktır.
- Tam ekran/immersive kullanım için hazırlanmıştır.
- Uygulama WebView içinde HTTPS üzerinden gerekli Milkdrop kütüphanelerini ilk kullanımda indirebilir; mevcut HTML tarafındaki IndexedDB önbellekleme mekanizması daha sonra çevrimdışı yüklemeyi destekler.

Not: Bu çalışma ortamında Android SDK/Gradle bulunmadığından burada doğrudan APK binary'si derlenemedi.
