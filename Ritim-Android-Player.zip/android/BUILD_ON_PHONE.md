# Ritim APK'yi telefondan oluşturma

Bu proje GitHub Actions ile bilgisayara Android Studio kurmadan APK derleyebilir.

1. GitHub'da yeni bir repository oluştur.
2. Bu klasörün içindeki dosyaları repository'ye yükle.
3. `.github/workflows/build-apk.yml` dosyası da yüklenmiş olmalı.
4. GitHub'da **Actions > Build Ritim APK > Run workflow** seç.
5. İşlem bitince **Ritim-debug-apk** adlı artifact'i indir.
6. ZIP'i açıp içindeki `app-debug.apk` dosyasını telefona kur.

Not: GitHub hesabında Actions çalışmasına izin verilmesi gerekir. APK debug imzalıdır; kendi telefonunda kurulum/test için uygundur.
