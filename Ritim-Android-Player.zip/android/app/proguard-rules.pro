# Ritim WebView app intentionally keeps JavaScript assets unobfuscated.
